﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
           // Fought();
            //Military.Fought();
           // UnitTestProject1.Military.Fought();

            //Mi

            //Mil.Fought();

        }

        private void Fought()
        {
            throw new NotImplementedException();
        }
    }
}
